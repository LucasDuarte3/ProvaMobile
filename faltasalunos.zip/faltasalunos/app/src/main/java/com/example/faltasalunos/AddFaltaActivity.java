package com.example.faltasalunos;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import com.example.faltasalunos.database.AppDatabase;
import com.example.faltasalunos.database.Falta;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddFaltaActivity extends AppCompatActivity {
    private AppDatabase db;
    private EditText editAluno, editDisciplina, editData, editMotivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_falta);

        db = AppDatabase.getInstance(this);

        editAluno = findViewById(R.id.editAluno);
        editDisciplina = findViewById(R.id.editDisciplina);
        editData = findViewById(R.id.editData);
        editMotivo = findViewById(R.id.editMotivo);

        // Valores padrão para facilitar testes
        editAluno.setText("João Silva");
        editDisciplina.setText("Programação Mobile");
        editData.setText(new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date()));
        editMotivo.setText("Falta justificada");

        Button btnSalvar = findViewById(R.id.btnSalvar);
        btnSalvar.setOnClickListener(v -> {
            Falta falta = new Falta();
            falta.setAlunoNome(editAluno.getText().toString());
            falta.setDisciplina(editDisciplina.getText().toString());
            falta.setData(editData.getText().toString());
            falta.setMotivo(editMotivo.getText().toString());

            db.faltaDao().insert(falta);
            finish();
        });
    }
}