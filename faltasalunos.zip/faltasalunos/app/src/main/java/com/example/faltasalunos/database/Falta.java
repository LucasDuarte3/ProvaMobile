package com.example.faltasalunos.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "faltas")
public class Falta {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String alunoNome;
    private String disciplina;
    private String data;
    private String motivo;

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAlunoNome() {
        return alunoNome;
    }

    public void setAlunoNome(String alunoNome) {
        this.alunoNome = alunoNome;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }
}
