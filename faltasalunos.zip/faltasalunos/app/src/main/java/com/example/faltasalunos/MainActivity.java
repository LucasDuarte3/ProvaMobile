package com.example.faltasalunos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import com.example.faltasalunos.Adapter.FaltaAdapter;
import com.example.faltasalunos.database.AppDatabase;
import com.example.faltasalunos.database.Falta;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private FaltaAdapter adapter;
    private AppDatabase db;
    private List<Falta> faltas = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = AppDatabase.getInstance(this);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new FaltaAdapter(faltas, this);
        recyclerView.setAdapter(adapter);

        loadFaltas();

        findViewById(R.id.btnAdd).setOnClickListener(v -> {
            startActivity(new Intent(this, AddFaltaActivity.class));
        });
    }

    private void loadFaltas() {
        faltas.clear();
        faltas.addAll(db.faltaDao().getAll());
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadFaltas();
    }

    public void deleteFalta(Falta falta) {
        db.faltaDao().delete(falta);
        loadFaltas();
    }

    public int getTotalFaltasPorAluno(String alunoNome) {
        return db.faltaDao().getTotalFaltasPorAluno(alunoNome);
    }
}