package com.example.faltasalunos.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.faltasalunos.R;
import com.example.faltasalunos.MainActivity;
import com.example.faltasalunos.database.Falta;

import java.util.List;

public class FaltaAdapter extends RecyclerView.Adapter<FaltaAdapter.FaltaViewHolder> {
    private final List<Falta> faltas;
    private final MainActivity activity;

    public FaltaAdapter(List<Falta> faltas, MainActivity activity) {
        this.faltas = faltas;
        this.activity = activity;
    }

    @NonNull
    @Override
    public FaltaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_falta, parent, false);
        return new FaltaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FaltaViewHolder holder, int position) {
        Falta falta = faltas.get(position);
        holder.textAluno.setText(falta.getAlunoNome());
        holder.textDisciplina.setText(falta.getDisciplina());
        holder.textData.setText(falta.getData());
        holder.textMotivo.setText(falta.getMotivo());

        int totalFaltas = activity.getTotalFaltasPorAluno(falta.getAlunoNome());
        holder.textTotalFaltas.setText("Total de faltas: " + totalFaltas);

        holder.btnDelete.setOnClickListener(v -> activity.deleteFalta(falta));
    }

    @Override
    public int getItemCount() {
        return faltas.size();
    }

    static class FaltaViewHolder extends RecyclerView.ViewHolder {
        TextView textAluno, textDisciplina, textData, textMotivo, textTotalFaltas;
        Button btnDelete;

        public FaltaViewHolder(@NonNull View itemView) {
            super(itemView);
            textAluno = itemView.findViewById(R.id.textAluno);
            textDisciplina = itemView.findViewById(R.id.textDisciplina);
            textData = itemView.findViewById(R.id.textData);
            textMotivo = itemView.findViewById(R.id.textMotivo);
            textTotalFaltas = itemView.findViewById(R.id.textTotalFaltas);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
