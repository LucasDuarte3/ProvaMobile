package com.example.faltasalunos.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface FaltaDao {
    @Query("SELECT * FROM faltas")
    List<Falta> getAll();

    @Insert
    void insert(Falta falta);

    @Delete
    void delete(Falta falta);

    @Query("SELECT COUNT(*) FROM faltas WHERE alunoNome = :alunoNome")
    int getTotalFaltasPorAluno(String alunoNome);
}
